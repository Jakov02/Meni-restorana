#define _CRT_SECURE_NO_WARNINGS

float calculatePrice(const char* filename, float price1, float price2, float price3, float price4, float price5) {
	float price = 0.0;
	int choice;

	openAndPrintFile(filename);

	printf("\nOdaberite broj (1-5): ");
	scanf("%d", &choice);

	switch (choice) {
	case 1:
		price += price1;
		break;
	case 2:
		price += price2;
		break;
	case 3:
		price += price3;
		break;
	case 4:
		price += price4;
		break;
	case 5:
		price += price5;
		break;
	default:
		printf("Pogre�an odabir. Cijena nije dodana.\n");
	}

	return price;
}