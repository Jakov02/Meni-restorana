﻿#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include "header.h"
#include "cijene.h"

int main() {

	printf("\n\t\t\tDobrodosli u restoran LATIFI\n");

	int choice;
	float ukupnaCijena = 0.0;
	float ukupnaCijenaKune = 0.0;

	do {
		printf("\nOdaberite opciju:\n\n");
		printf("Odaberite broj 1 za izbor vina\n");
		printf("Odaberite broj 2 za izbor hors d'oeuvre\n");
		printf("Odaberite broj 3 za izbor apetizer\n");
		printf("Odaberite broj 4 za izbor glavna jela\n");
		printf("Odaberite broj 5 za izbor salate\n");
		printf("Odaberite broj 6 za izbor deserta\n");
		printf("Odaberite broj 7 za zavrsetak narudzbe.\n");

		printf("Odabir: ");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			ukupnaCijena += calculatePrice("Vina.txt", 30.0, 40.0, 55.0, 70.0, 100.0);
			break;
		case 2:
			ukupnaCijena += calculatePrice("hors.txt", 2.0, 1.0, 3.0, 2.5, 1.2);
			break;
		case 3:
			ukupnaCijena += calculatePrice("apetizer.txt", 6.25, 1.25, 8.95, 1.50, 2.50);
			break;
		case 4:
			ukupnaCijena += calculatePrice("maincourse.txt", 7.0, 8.20, 8.50, 10.0, 10.40);
			break;
		case 5:
			ukupnaCijena += calculatePrice("salad.txt", 3.0, 7.20, 3.70, 3.20, 3.50);
			break;
		case 6:
			ukupnaCijena += calculatePrice("dessert.txt", 3.50, 3.60, 3.60, 3.50, 6.00);
			break;
		case 7:
			float ukupnaCijenaKune = 7.53 * ukupnaCijena;
			printf("Ukupna cijena: %.2f Eura\nUkupna cijena: %.2f Kn\n", ukupnaCijena, ukupnaCijenaKune);
			printf("Završetak programa.\n");
			break;
		default:
			printf("Pogrešan odabir. Pokušajte ponovno.\n");
		}
	} while (choice != 7);

	return 0;
}
