#define _CRT_SECURE_NO_WARNINGS
#ifndef CIJENE_H
#define CIJENE_H

float calculatePrice(const char* filename, float price1, float price2, float price3, float price4, float price5);

#endif

