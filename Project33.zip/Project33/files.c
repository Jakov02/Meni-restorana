﻿#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

void openAndPrintFile(const char* filename) {
	FILE* file = fopen(filename, "r");
	char ch;

	if (file == NULL) {
		printf("Greška pri otvaranju datoteke.\n");
		return;
	}

	printf("\nSadržaj datoteke \"%s\":\n", filename);
	while ((ch = fgetc(file)) != EOF) {
		putchar(ch);
	}

	fclose(file);
}

