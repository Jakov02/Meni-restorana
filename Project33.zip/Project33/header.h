#define _CRT_SECURE_NO_WARNINGS
#ifndef HEADER_H
#define HEADER_H

void openAndPrintFile(const char* filename);

#endif


