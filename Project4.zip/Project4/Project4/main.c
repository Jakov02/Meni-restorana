﻿#define _CRT_SECURE_NO_WARNINGS
#define EURO = 7.5326
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"

int main() {
    int fileBroj;

   printf("====================");
    printf("Odaberite jednu od ponudenih opcija za pregled menija:");
    printf("====================\n");
    printf("\t\t\tOpcija 1: Vina\n");
    printf("\t\t\tOpcija 2: Hors d'oeuvre\n");
    printf("\t\t\tOpcija 3: apetizeri\n");
    printf("\t\t\tOpcija 4: salate \n");
    printf("\t\t\tOpcija 5: glavna jela \n");
    printf("\t\t\tOpcija 6: desert \n");
    printf("\t\t\tOpcija 7: Zatvaranje menija\n");
    printf("======================================\
			======================================\n");
  

    scanf("%d", &fileBroj);
    
    izbornik(fileBroj);

    return 0;
}



