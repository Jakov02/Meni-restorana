#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"


void izbornik(int fileNumber) {
    FILE* pF;
    char fileIme[1000];
    switch (fileNumber) {
    case 1:
        strcpy(fileIme, "Vina.txt");
        break;
    case 2:
        strcpy(fileIme, "hors.txt");
        break;
    case 3:
        strcpy(fileIme, "apetizer.txt");
        break;
    case 4:
        strcpy(fileIme, "salad.txt");
        break;
    case 5:
        strcpy(fileIme, "maincourse.txt");
        break;
    case 6:
        strcpy(fileIme, "dessert.txt");
        break;
    default:
        printf("Invalid file number.\n");
        return;
    }
    
   

    pF = fopen(fileIme, "r");
    if (pF == NULL) {
        printf("Failed to open the file: %s\n", fileIme);
        return;
    }

    char ch;
    while ((ch = fgetc(pF)) != EOF) {
        putchar(ch);
    }

    fclose(pF);
}








